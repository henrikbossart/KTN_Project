

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class MessageReciever {

    private Socket clientSocket;
    private BufferedReader incoming;
    private ArrayList<JSONObject> messages = new ArrayList<JSONObject>();
    private Client listener;
    private boolean running;
    private JSONParser parser = new JSONParser();
    private JSONObject message;

    public MessageReciever(Socket socket) {
        this.clientSocket = socket;
        try {
            incoming = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean hasMessage() {
        if (messages.size() > 1) {
            return true;
        } else {
            return false;
        }
    }

    public JSONObject getMessage() {
        if (!(messages.size() == 0)) {
            JSONObject message = messages.get(0);
            messages.remove(0);
            return message;
        }
        return null;
    }

    public void addListener(Client client) {
        listener = client;
    }

    public void run() {
        running = true;
        String text = "";
        while (running) {
                try {
                    text = incoming.readLine();
                    message = (JSONObject) parser.parse(text);
                    System.out.println(message);
                } catch (ParseException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            if (message != null) {
                messages.add(message);
                listener.messageRecieved();

            }

        }
    }

}
