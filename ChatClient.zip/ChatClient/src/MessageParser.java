
import org.json.simple.JSONObject;

import javax.swing.*;

public class MessageParser {

    private String timestamp;
    private String response;
    private String content;
    private String sender;
    private JSONObject payload;
    private JTextArea chatLog;

    //Initializes the parser
    public MessageParser(JTextArea chatLog) {
        this.chatLog = chatLog;
    }

    public void setPayload(JSONObject payload) {
        this.payload = payload;
        if (payloadChecker()) {
            payloadSplitter();
            logger();
        }
    }

    private void payloadSplitter() {
        this.timestamp = (String) payload.get("timestamp");
        this.response = (String) payload.get("response");
        this.content = (String) payload.get("content");
        this.sender = (String) payload.get("sender");
    }

    public boolean payloadChecker() {
        if (!payload.containsKey("timestamp") ||
                !payload.containsKey("response") ||
                !payload.containsKey("content") ||
                !payload.containsKey("sender")) {
            Client.errorLogger("payload does not contain all required elements!");
            return false;
        }
        return true;
    }

    public void logger() {
        String decodedMessage = timestamp + " (" + sender + "): " + content;
        chatLog.append(decodedMessage);
    }




}